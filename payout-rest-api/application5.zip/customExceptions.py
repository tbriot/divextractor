class ValidationException(Exception):
    pass


class DbConnectionException(Exception):
    pass


class DuplicateException(Exception):
    pass


class ConflictException(Exception):
    pass
